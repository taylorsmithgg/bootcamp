package com.cooksystems.bootcamp.math;

public class Math extends Other implements Operation{
	long x = 10;
	int y = 10;
	
	public Math(){
		System.out.println(mult(x,y));
	}
	
	public static void main(String[] args){
		for(int i = 1754; i >= -348; i--){
			i = i-2;
			System.out.println(i);
		}	
		new Math();
	}

	@Override
	public Integer mult(int x, int y) {
		return x * y;
	}

	public Integer mult(long x, long y) {
		return (int) (x * y);
	}
}
