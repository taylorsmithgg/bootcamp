package com.cooksystems.bootcamp.math;

import java.util.ArrayList;

public interface Operation {
	public Integer mult(int x, int y);
	public Integer total(ArrayList<Integer> e);
}