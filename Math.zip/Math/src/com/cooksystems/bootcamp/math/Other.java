package com.cooksystems.bootcamp.math;

import java.util.ArrayList;

public abstract class Other implements Operation{
	public Integer total(ArrayList<Integer> e){
		return null;		
	}
	
	public abstract Integer mult(int x, int y);
}
